"""Read token counters from local JSONL session logs."""
import json
import os
from datetime import datetime
from pathlib import Path


def jsonl(path, markers):
    with path.open("rb") as stream:
        for line in stream:
            if not any(marker in line for marker in markers):
                continue
            try:
                record = json.loads(line)
            except (ValueError, UnicodeError):
                continue  # A running session may still be writing its last record.
            if isinstance(record, dict):
                yield record


def local_day(timestamp):
    try:
        return datetime.fromisoformat(timestamp.replace("Z", "+00:00")).astimezone().date().isoformat()
    except (AttributeError, ValueError, OverflowError):
        return None


def counter(record, key):
    value = record.get(key, 0)
    return value if type(value) is int and 0 <= value <= 2**53 - 1 else 0


def codex_file(path):
    total_before = None
    model, turn = "unknown", ""
    for row in jsonl(path, (b'"turn_context"', b'"token_count"')):
        payload = row.get("payload")
        if not isinstance(payload, dict):
            continue
        if row.get("type") == "turn_context":
            model = payload.get("model") or "unknown"
            turn = payload.get("turn_id") or ""
            continue
        info = payload.get("info")
        if row.get("type") != "event_msg" or payload.get("type") != "token_count" or not isinstance(info, dict):
            continue
        cumulative = info.get("total_token_usage")
        last = info.get("last_token_usage")
        if not isinstance(cumulative, dict) or not isinstance(last, dict):
            continue
        keys = ("input_tokens", "cached_input_tokens", "cache_write_input_tokens", "output_tokens")
        total = tuple(counter(cumulative, key) for key in keys)
        qty = tuple(counter(last, key) for key in keys)
        if total == total_before:
            continue
        # Skip context-size estimates or restored snapshots that do not advance
        # the cumulative billing counters by the most recent call.
        expected = tuple(a + b for a, b in zip(total_before or (0, 0, 0, 0), qty))
        total_before = total
        if expected != total:
            continue
        stamp = row.get("timestamp")
        day = local_day(stamp)
        if day and sum(qty):
            inp, cached, written, output = qty
            cached = min(cached, inp)
            written = min(written, inp - cached)
            yield (turn, stamp, total), dict(date=day, tool="codex", model=str(model),
                input=inp, output=output, cached=cached, written=written)


def claude_file(path):
    for row in jsonl(path, (b'"usage"',)):
        message = row.get("message")
        if row.get("type") != "assistant" or not isinstance(message, dict):
            continue
        usage = message.get("usage")
        model = message.get("model")
        day = local_day(row.get("timestamp"))
        if not day or not isinstance(usage, dict) or not model or model == "<synthetic>":
            continue
        ordinary = counter(usage, "input_tokens")
        written = counter(usage, "cache_creation_input_tokens")
        cached = counter(usage, "cache_read_input_tokens")
        output = counter(usage, "output_tokens")
        inp = ordinary + written + cached
        if inp + output:
            yield row.get("requestId") or message.get("id") or row.get("uuid"), dict(
                date=day, tool="claude-code", model=str(model), input=inp,
                output=output, cached=cached, written=written)


def read_cached(paths, parser, cache):
    chosen = {}
    anonymous = []
    current = set()
    for path in paths:
        current.add(path)
        try:
            meta = path.stat()
            fingerprint = (meta.st_size, meta.st_mtime_ns)
            prior = cache.get(path)
            if prior is None or prior[0] != fingerprint:
                prior = (fingerprint, list(parser(path)))
                cache[path] = prior
        except OSError:
            continue
        for identity, item in prior[1]:
            if identity is None:
                anonymous.append(item)
            else:
                previous = chosen.get(identity)
                if previous is None or item["input"] + item["output"] > previous["input"] + previous["output"]:
                    chosen[identity] = item
    for gone in cache.keys() - current:
        del cache[gone]
    return [*chosen.values(), *anonymous]


def collect_local(home, caches):
    codex = Path(os.environ.get("CODEX_HOME", home / ".codex"))
    claude = Path(os.environ.get("CLAUDE_CONFIG_DIR", home / ".claude"))
    sessions = list(codex.glob("sessions/**/*.jsonl")) + list(codex.glob("archived_sessions/*.jsonl"))
    return (read_cached(sessions, codex_file, caches.setdefault("codex", {}))
            + read_cached(claude.glob("projects/**/*.jsonl"), claude_file, caches.setdefault("claude", {})))
