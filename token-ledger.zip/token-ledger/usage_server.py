"""Local-only usage dashboard. Run python3 usage_server.py --open on your computer."""
import csv
import io
import json
import mimetypes
import os
import tempfile
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from collections import defaultdict
from datetime import date, datetime
from local_collectors import collect_local
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PORT = 48731
ORIGIN = f'http://127.0.0.1:{PORT}'
FILES = {'index.html','styles.css','app.js','models.js','pricing.js','share.js','usage.html','usage.css','usage.js','theme.js','billing.js','usage-card.js'}
FIELDS = ('input','output','cached','written')
LOCK = threading.Lock()
STATE = {'rows': [], 'updated': None, 'warnings': [], 'busy': False}
last_attempt = 0.
COLLECTOR_CACHE = {}


def count(value):
    if type(value) is not int or value < 0 or value > 2**53-1:
        raise ValueError('Invalid token count')
    return value


def normalize(raw):
    day = date.fromisoformat(raw['date']).isoformat()
    cached = count(raw.get('cache_read', 0))
    written = count(raw.get('cache_write', 0))
    return dict(date=day, tool=str(raw['tool']), model=str(raw.get('model') or 'unknown'),
                input=count(raw['input'])+cached+written, output=count(raw['output']),
                cached=cached, written=written)


def aggregate(rows):
    grouped = defaultdict(lambda: dict.fromkeys(FIELDS, 0))
    for row in rows:
        sums = grouped[row['date'],row['tool'],row['model']]
        for key in FIELDS:
            sums[key] += row[key]
    return [dict(date=d,tool=t,model=m,**s) for (d,t,m),s in sorted(grouped.items()) if s['input']+s['output']]


def merge_sources(native, fallback):
    covered = {(r['tool'],r['date']) for r in native}
    return aggregate([*native, *(r for r in fallback if (r['tool'],r['date']) not in covered)])


def cursor_rows(home):
    file = home/'.opentoken/cache/cursor.json'
    if not file.is_file():
        return []
    # Use the exported total to reconcile the differing Cursor CSV header conventions.
    csv_text = json.loads(file.read_bytes())['csv']
    rows = []
    for r in csv.DictReader(io.StringIO(csv_text)):
        output = int(r['Output Tokens'] or 0)
        inp = count(int(r['Total Tokens'] or 0)-output)
        cached = count(int(r['Cache Read'] or 0))
        plain = count(int(r['Input (w/o Cache Write)'] or 0))
        if not inp+output: continue
        rows.append(normalize(dict(date=datetime.fromisoformat(r['Date'].replace('Z','+00:00')).astimezone().date().isoformat(),
            tool='cursor',model=r['Model'],input=plain,output=output,cache_read=cached,cache_write=count(inp-cached-plain))))
    return rows


def opencode_rows(home):
    rows, seen = [], set()
    for file in (home/'.local/share/opencode/storage/message').glob('*/*.json'):
        r = json.loads(file.read_bytes())
        if r.get('role')!='assistant' or not r.get('tokens') or r.get('id') in seen: continue
        seen.add(r['id'])
        u = r['tokens']
        stamp = r['time'].get('completed') or r['time']['created']
        cache = u.get('cache') or {}
        rows.append(normalize(dict(date=datetime.fromtimestamp(stamp/1000).date().isoformat(),tool='opencode',
            model=r.get('modelID'),input=u['input'],output=u['output'],cache_read=cache.get('read',0),cache_write=cache.get('write',0))))
    return rows


def save_history(rows, directory):
    """Replace each reported tool/day as a unit, retaining days that rotated off disk."""
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    dest = directory/'daily-v1.json'
    previous = json.loads(dest.read_bytes()) if dest.exists() else []
    combined = merge_sources(rows, previous)
    with tempfile.NamedTemporaryFile(mode='w', dir=directory, delete=False) as tmp:
        try:
            json.dump(combined,tmp,ensure_ascii=False,separators=(',',':'))
            tmp.flush()
            os.fsync(tmp.fileno())
            os.replace(tmp.name,dest)
        finally:
            Path(tmp.name).unlink(missing_ok=True)
    return combined


def history_dir(home):
    if sys.platform == 'darwin':
        return home/'Library/Application Support/Token Ledger'
    if sys.platform == 'win32':
        return Path(os.environ.get('LOCALAPPDATA', home/'AppData/Local'))/'Token Ledger'
    return Path(os.environ.get('XDG_DATA_HOME', home/'.local/share'))/'token-ledger'


def collect():
    home = Path.home()
    issues, native, fallback = [], [], []
    exe = shutil.which('opentoken')
    installed = home/'.local/bin/opentoken'
    if not exe and installed.is_file():
        exe = str(installed)
    sandbox = Path('/usr/bin/sandbox-exec')
    if exe and sandbox.is_file():
        cmd = [str(sandbox),'-p','(version 1)(allow default)(deny network*)',exe,'preview','--json']
        try:
            proc = subprocess.run(cmd, capture_output=True, timeout=120, check=True)
            native = [normalize(r) for r in json.loads(proc.stdout)['rows']]
        except (OSError,subprocess.SubprocessError,ValueError,KeyError,TypeError):
            issues.append('OpenToken 暂时不可用，已尝试使用内置读取器。')
    try:
        if not native:
            fallback.extend(collect_local(home,COLLECTOR_CACHE))
        for name, reader in [('Cursor',cursor_rows),('OpenCode',opencode_rows)]:
            try: fallback.extend(reader(home))
            except (OSError,ValueError,KeyError,TypeError): issues.append(name+' 本地记录读取失败')
        rows = merge_sources(native, fallback)
        try:
            rows = save_history(rows, history_dir(home))
        except (ValueError,OSError,KeyError,TypeError):
            issues.append('本机历史归档暂不可用，本次显示当前扫描结果')
        with LOCK:
            STATE.update(rows=rows,updated=datetime.now().astimezone().isoformat(timespec='seconds'),warnings=issues)
    except (OSError,subprocess.SubprocessError,ValueError,KeyError,TypeError):
        with LOCK: STATE['warnings'] = ['本地采集失败，将自动重试。请检查会话日志权限。']
    finally:
        with LOCK: STATE['busy'] = False


def snapshot():
    global last_attempt
    with LOCK:
        if not STATE['busy'] and time.monotonic()-last_attempt >= 15:
            STATE['busy'] = True
            last_attempt = time.monotonic()
            threading.Thread(target=collect,daemon=True).start()
        return json.dumps(STATE,ensure_ascii=False).encode()


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.headers.get('Host') != f'127.0.0.1:{PORT}' or self.headers.get('Origin',ORIGIN) != ORIGIN or self.headers.get('Sec-Fetch-Site')=='cross-site' and (self.path.startswith('/api/') or self.headers.get('Sec-Fetch-Mode')!='navigate'):
            return self.send_error(403)
        route = self.path.split('?')[0]
        if route=='/api/usage':
            data, mime = snapshot(), 'application/json'
        elif route=='/health':
            data, mime = b'token-ledger-local-v1','text/plain'
        else:
            name = route[1:] or 'usage.html'
            if name not in FILES: return self.send_error(404)
            data, mime = (ROOT/name).read_bytes(), mimetypes.guess_type(name)[0] or 'application/octet-stream'
        self.send_response(200)
        for key,value in [('Content-Type',mime+'; charset=utf-8'),('Cache-Control','no-store'),('X-Content-Type-Options','nosniff'),('X-Frame-Options','DENY'),('Referrer-Policy','no-referrer'),('Content-Length',str(len(data)))]:
            self.send_header(key,value)
        self.end_headers()
        try: self.wfile.write(data)
        except (BrokenPipeError,ConnectionResetError): pass
    def log_message(self,*args): pass


if __name__=='__main__':
    try:
        server = ThreadingHTTPServer(('127.0.0.1',PORT),Handler)
    except OSError:
        try:
            with urllib.request.urlopen(ORIGIN+'/health',timeout=2) as response:
                if response.read(80)!=b'token-ledger-local-v1': raise ValueError()
        except Exception: sys.exit('用量看板端口已被其他程序占用。')
        if '--open' in sys.argv: webbrowser.open(ORIGIN)
        sys.exit(0)
    print('用量看板 '+ORIGIN+'  ·  Ctrl+C 停止',flush=True)
    snapshot()
    if '--open' in sys.argv: webbrowser.open(ORIGIN)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
