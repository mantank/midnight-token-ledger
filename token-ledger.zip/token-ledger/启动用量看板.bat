@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 usage_server.py --open
) else (
  python usage_server.py --open
)
if errorlevel 1 pause
